package com.eazybytes.loans;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoansApplicationTests {

	@Test
	void contextLoads() {
	}

}

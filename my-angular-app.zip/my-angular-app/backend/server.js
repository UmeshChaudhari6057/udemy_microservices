const express = require('express');
const axios = require('axios');
const app = express();
const PORT = 3000;
const cors = require('cors'); 

app.use(cors());

app.get('/api/market-data', async (req, res) => {
  try {
    const response = await axios.get(
      'https://serpapi.com/search.json?engine=google_finance&q=GOOGL:NASDAQ&api_key=1bfbfb14fd4a16ea565e478d721bd15ad5dd73d12fe4c4082476ca9ed70369a8'
    );
    res.json(response.data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

import { CanActivateFn } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';

export const authGuard: CanActivateFn = () => {
 const authService = inject(AuthService);
  const router = inject(Router);
  const role = authService.getRole();

  const url = router.url;

  if (!authService.isLoggedIn()) {
    router.navigate(['/login']);
    return false;
  }

  if (url.includes('admin') && role !== 'ADMIN') {
    router.navigate(['/login']);
    return false;
  }
  if (url.includes('trader') && role !== 'TRADER') {
    router.navigate(['/login']);
    return false;
  }
  if (url.includes('viewer') && role !== 'VIEWER') {
    router.navigate(['/login']);
    return false;
  }

  return true;

};

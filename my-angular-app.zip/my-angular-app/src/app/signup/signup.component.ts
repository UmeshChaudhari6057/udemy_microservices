import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../auth.service';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  username = '';
  password = '';
  role = 'VIEWER'; // 👈 Default role
  errorMessage = '';

  constructor(private router: Router) {}

  onSignup(): void {
const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');
const exists = users.some((u: User) => u.username === this.username);
    if (exists) {
      this.errorMessage = 'Username already exists';
      return;
    }

    users.push({ username: this.username, password: this.password, role: this.role });
    localStorage.setItem('users', JSON.stringify(users));
    alert('Signup successful! Please login.');
    this.router.navigate(['/login']);
  }

  goToLogin(): void {
  this.router.navigate(['/login']);
}
}
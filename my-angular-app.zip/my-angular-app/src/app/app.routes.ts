import { Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MarketOverviewComponent } from './market-overview/market-overview.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { PostlistComponent } from './postlist/postlist.component';
import { LoginComponent } from './login/login.component';
import { authGuard } from './auth.guard';
import { UserformComponent } from './userform/userform.component';
import { AdminComponent } from './admin/admin.component';
import { TraderComponent } from './trader/trader.component';
import { ViewerComponent } from './viewer/viewer.component';
import { SignupComponent } from './signup/signup.component';
export const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent ,canActivate: [authGuard]},
  { path: 'market', component: MarketOverviewComponent },
  { path: 'portfolio', component: PortfolioComponent },
  {path:'posts',component:PostlistComponent},  
  { path: 'login', component: LoginComponent },  
    { path: 'login', component: LoginComponent },
  { path: 'admin', component: AdminComponent, canActivate: [authGuard] },
  { path: 'trader', component: TraderComponent, canActivate: [authGuard] },
  { path: 'viewer', component: ViewerComponent, canActivate: [authGuard] },     
  {path:'userform', component:UserformComponent, canActivate: [authGuard]},
  { path: 'signup', component: SignupComponent },
  { path: '', redirectTo: 'signup', pathMatch: 'full' }
];



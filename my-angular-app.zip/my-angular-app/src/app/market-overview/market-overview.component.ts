import { CommonModule } from '@angular/common';
import { Component,OnInit } from '@angular/core';
import { HeaderComponent } from '../header/header.component';


import { MarketDataService,MarketData } from '../service/market-data.service';

@Component({
  selector: 'app-market-overview',
  imports: [CommonModule, HeaderComponent],
  templateUrl: './market-overview.component.html',
  styleUrl: './market-overview.component.css'
})
export class MarketOverviewComponent implements OnInit {
  marketData: MarketData[] = [];

  constructor(private marketService: MarketDataService) {}

  ngOnInit(): void {
    this.marketService.getLiveData().subscribe({
      next: (data) => this.marketData = data,
      error: (err) => console.error('Error fetching market data', err)
    });
  }
}


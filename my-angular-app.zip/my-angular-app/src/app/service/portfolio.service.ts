import { Injectable } from '@angular/core';


export interface Holding {
  symbol: string;
  quantity: number;
  avgPrice: number;
}

@Injectable({ providedIn: 'root' })
export class PortfolioService {
  private holdings: Holding[] = [];

  getHoldings(): Holding[] {
    return this.holdings;
  }

  addOrder(symbol: string, quantity: number, price?: number) {
    const existing = this.holdings.find(h => h.symbol === symbol);
    if (existing) {
      const totalQty = existing.quantity + quantity;
      existing.avgPrice =
        ((existing.avgPrice * existing.quantity) + (price || 0) * quantity) / totalQty;
      existing.quantity = totalQty;
    } else {
      this.holdings.push({ symbol, quantity, avgPrice: price || 0 });
    }
  }
}

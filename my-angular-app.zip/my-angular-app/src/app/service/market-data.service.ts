// market-data.service.ts
import { Injectable } from '@angular/core';
import { Observable, interval } from 'rxjs';
import { map } from 'rxjs/operators';

export interface MarketData {
  symbol: string;
  price: number;
  change: number;
}

@Injectable({ providedIn: 'root' })
export class MarketDataService {
  private symbols = ['AAPL', 'TSLA', 'GOOG', 'AMZN', 'MSFT'];

  getLiveData(): Observable<MarketData[]> {
    return interval(2000).pipe(
      map(() =>
        this.symbols.map(symbol => ({
          symbol,
          price: +(100 + Math.random() * 1000).toFixed(2),
          change: +(Math.random() * 10 - 5).toFixed(2)
        }))
      )
    );
  }
}

// market-data.service.ts
// import { Injectable } from '@angular/core';
// import { Observable, interval } from 'rxjs';
// import { map } from 'rxjs/operators';

// export interface MarketData {
//   symbol: string;
//   price: number;
//   change: number;
// }

// @Injectable({ providedIn: 'root' })
// export class MarketDataService {
//   private symbols = ['AAPL', 'TSLA', 'GOOG', 'AMZN', 'MSFT'];

//   getLiveData(): Observable<MarketData[]> {
//     return interval(2000).pipe(
//       map(() =>
//         this.symbols.map(symbol => ({
//           symbol,
//           price: +(100 + Math.random() * 1000).toFixed(2),
//           change: +(Math.random() * 10 - 5).toFixed(2)
//         }))
//       )
//     );
//   }
// }
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';

export interface MarketData {
  symbol: string;
  price: number;
  change: number;
}

@Injectable({
  providedIn: 'root'
})
export class MarketDataService {
  // 🔹 SerpApi URL with your API key
  //private apiUrl = 'https://serpapi.com/search.json?engine=google_finance&q=GOOGL:NASDAQ&api_key=1bfbfb14fd4a16ea565e478d721bd15ad5dd73d12fe4c4082476ca9ed70369a8';
  
    private apiUrl = 'http://localhost:3000/api/market-data';

  constructor(private http: HttpClient) {}

  // 🔹 Raw API call (optional)
  getMarketData(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  // 🔹 Transformed data into MarketData[]
  getLiveData(): Observable<MarketData[]> {
    return this.http.get<any>(this.apiUrl).pipe(
      map((response: any) => {
        // Handle markets data; adapt based on actual response
        const usMarkets = response.markets?.us || [];
        const europeMarkets = response.markets?.europe || [];

        // Combine US and Europe markets
        const allMarkets = [...usMarkets, ...europeMarkets];

        // Map to MarketData[]
        return allMarkets.map((m: any) => ({
          symbol: m.stock,
          price: m.price,
          change: m.price_movement?.percentage || 0
        }));
      })
    );
  }
}

export interface Order {
  id: number;
  symbol: string;
  type: 'Market' | 'Limit' | 'Stop';
  quantity: number;
  price?: number;
  status: 'Pending' | 'Executed' | 'Cancelled';
}

import { Component } from '@angular/core';
import { Order } from './order.model';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../header/header.component';
import { PortfolioService } from '../service/portfolio.service';
import { MarketDataService } from '../service/market-data.service';
import { MarketData } from '../service/market-data.service';
@Component({
  selector: 'app-order',
  standalone: true,
  imports: [CommonModule, FormsModule, HeaderComponent],
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent {

 constructor(private portfolioService: PortfolioService,private marketDataService: MarketDataService) {}
livePrice: number | null = null;
  newOrder: Partial<Order> = {
    type: 'Market',
    quantity: 0,
    symbol: ''
  };

  orders: Order[] = [];
  private orderId = 1;

  isEditing = false;
  editingOrderId: number | null = null;

  placeOrder() {
    if (!this.newOrder.symbol || !this.newOrder.quantity) {
      alert('Please fill all required fields');
      return;
    }

    if (this.isEditing && this.editingOrderId !== null) {
      // Update existing order
      const orderIndex = this.orders.findIndex(o => o.id === this.editingOrderId);
      if (orderIndex > -1) {
        this.orders[orderIndex] = {
          ...this.orders[orderIndex],
          symbol: this.newOrder.symbol,
          type: this.newOrder.type as 'Market' | 'Limit' | 'Stop',
          quantity: this.newOrder.quantity!,
          price: this.newOrder.type === 'Market' ? undefined : this.newOrder.price,
          status: 'Pending'
        };
      }
      this.isEditing = false;
      this.editingOrderId = null;
    } else {
      // Add new order
      const order: Order = {
        id: this.orderId++,
        symbol: this.newOrder.symbol,
        type: this.newOrder.type as 'Market' | 'Limit' | 'Stop',
        quantity: this.newOrder.quantity!,
        price: this.newOrder.type === 'Market' ? undefined : this.newOrder.price,
        status: 'Pending'
      };
      this.orders.push(order);
      //  👉 Add order to portfolio
      this.portfolioService.addOrder(order.symbol, order.quantity, order.price);
    }

    this.newOrder = { type: 'Market', quantity: 0, symbol: '' }; // reset form
  }

  editOrder(order: Order) {
    this.isEditing = true;
    this.editingOrderId = order.id;
    this.newOrder = { ...order }; // prefill form
  }

  cancelEdit() {
    this.isEditing = false;
    this.editingOrderId = null;
    this.newOrder = { type: 'Market', quantity: 0, symbol: '' }; // reset form
  }

  cancelOrder(order: Order) {
    order.status = 'Cancelled';
  }

   onSymbolChange() {
  if (this.newOrder.symbol) {
    this.marketDataService
      .getPriceForSymbol(this.newOrder.symbol)
      .subscribe(price => this.livePrice = price);
  } else {
    this.livePrice = null;
  }
}
}

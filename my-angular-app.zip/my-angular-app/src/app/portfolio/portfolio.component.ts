import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { Holding, PortfolioService } from '../service/portfolio.service';
@Component({
  selector: 'app-portfolio',
  imports: [CommonModule,HeaderComponent],
  templateUrl: './portfolio.component.html',
  styleUrl: './portfolio.component.css'
})
export class PortfolioComponent implements OnInit {
  holdings: Holding[] = [];

  constructor(private portfolioService: PortfolioService) {}

  ngOnInit(): void {
    // load holdings from the shared service
    this.holdings = this.portfolioService.getHoldings();
  }
}
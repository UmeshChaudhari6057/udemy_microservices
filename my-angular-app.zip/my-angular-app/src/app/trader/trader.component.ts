import { Component } from '@angular/core';

@Component({
  selector: 'app-trader',
  imports: [],
  templateUrl: './trader.component.html',
  styleUrl: './trader.component.css'
})
export class TraderComponent {

}

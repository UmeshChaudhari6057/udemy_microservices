
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../header/header.component';
import { MarketDataService, MarketData } from '../service/market-data.service';
 
@Component({
  selector: 'app-dashboard',
  imports: [[CommonModule, HeaderComponent]],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {
  marketData: MarketData[] = [];


 constructor(public authService: AuthService
  ,private marketService: MarketDataService) {}
 
 
 ngOnInit() {
    this.marketService.getLiveData().subscribe(data => {
      this.marketData = data;
    });
  }
}

function ngOnInit() {
  throw new Error('Function not implemented.');
}

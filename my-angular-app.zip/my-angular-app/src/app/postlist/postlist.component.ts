import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { PostService ,Post} from '../post.service';

@Component({
  selector: 'app-postlist',
  imports: [CommonModule],
  templateUrl: './postlist.component.html',
  styleUrl: './postlist.component.css'
})
export class PostlistComponent implements OnInit{
   posts: Post[] =[];


   constructor(private postService :PostService){}

   ngOnInit(): void {
    this.postService.getPosts().subscribe(data => {
      this.posts = data;
    });

   }
}

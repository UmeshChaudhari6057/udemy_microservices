import { Injectable } from '@angular/core';

export interface User {
  username: string;
  password: string;
  role: string;
}
@Injectable({
  providedIn: 'root'
})
export class AuthService {
login(username: string, password: string): boolean {
  const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');
  const matchedUser = users.find(u => u.username === username && u.password === password);

  if (matchedUser) {
    localStorage.setItem('isLoggedIn', 'true');
    localStorage.setItem('role', matchedUser.role);
    localStorage.setItem('loginTime', Date.now().toString());
    return true;
  }

  return false;
}

  logout(): void {
    localStorage.clear();
  }

  isLoggedIn(): boolean {
    return localStorage.getItem('isLoggedIn') === 'true';
  }

  getRole(): string | null {
    return localStorage.getItem('role');
  }

  isSessionExpired(): boolean {
  const loginTime = parseInt(localStorage.getItem('loginTime') || '0');
  const now = Date.now();
  const sessionDuration = 30 * 60 * 1000; // 30 minutes
  return now - loginTime > sessionDuration;
}
}
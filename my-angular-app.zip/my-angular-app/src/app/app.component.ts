import { Component } from '@angular/core';
import { RouterModule, RouterOutlet ,Router,NavigationEnd} from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { MarketOverviewComponent } from './market-overview/market-overview.component';
import { filter } from 'rxjs/operators';
import { AuthService } from './auth.service';
import { OrderComponent } from './order/order.component';
@Component({
  selector: 'app-root',
  imports: [RouterOutlet,RouterModule, HeaderComponent,MarketOverviewComponent,OrderComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'my-angular-app';
  showHeader = true;

 constructor(private authService: AuthService, private router: Router) {}

ngOnInit(): void {
  setInterval(() => {
    if (this.authService.isLoggedIn() && this.authService.isSessionExpired()) {
      this.authService.logout();
      alert('⏳ Session expired. Please login again.');
      this.router.navigate(['/login']);
    }
  }, 60 * 1000); // check every minute
}


  
}
